# GembaPay for WooCommerce

**Unified payment gateway for crypto, cards, and PayPal in WooCommerce.**

Accept ETH, BNB, POL, USDC, USDT, credit cards (via Stripe), Apple Pay, Google Pay, and PayPal through a single checkout page. Non-custodial crypto payments — funds go directly to your wallet.

[![WordPress](https://img.shields.io/badge/WordPress-5.8%2B-blue)](https://wordpress.org)
[![WooCommerce](https://img.shields.io/badge/WooCommerce-5.0%2B-purple)](https://woocommerce.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

---

## Features

- **One checkout, all methods** — Crypto + Cards + PayPal on a single page
- **Non-custodial crypto** — Smart contract payments direct to your wallet
- **86+ currencies** — Price products in any currency
- **Zero configuration for crypto** — Works out of the box with your wallet address
- **Automatic order updates** — Real-time webhooks keep orders in sync
- **Test mode** — Develop with testnets before going live
- **HPOS compatible** — Works with WooCommerce High-Performance Order Storage

## Installation

1. Download the plugin ZIP
2. WordPress Admin → Plugins → Add New → Upload Plugin
3. Activate and go to WooCommerce → Settings → Payments → GembaPay
4. Enter your API Key and Webhook Secret
5. Enable the gateway

### Webhook URL

Set this in your [Merchant Dashboard](https://merchant.gembapay.com):

```
https://yoursite.com/wc-api/gembapay-webhook/
```

## Test Mode

Use your test API key (`gembapay_test_...`) in plugin settings:

| Method | Test Environment |
|--------|-----------------|
| Crypto | Sepolia, BSC Testnet, Polygon Amoy |
| Stripe | Test card `4242 4242 4242 4242` |
| PayPal | Sandbox accounts |

## Fee Structure

| Method | Fee |
|--------|-----|
| Crypto (ETH, BNB, POL, USDC, USDT) | 1% |
| Stripe (Cards, Apple Pay, Google Pay) | 1% + €0.20 + Stripe fees |
| PayPal (Balance, Bank, Pay Later) | 1% + €0.20 + PayPal fees |

## Requirements

- WordPress 5.8+
- WooCommerce 5.0+
- PHP 7.4+
- GembaPay merchant account with approved KYC

## Links

- [Documentation](https://docs.gembapay.com)
- [Merchant Dashboard](https://merchant.gembapay.com)
- [Integration Guide](https://docs.gembapay.com/integration)
- [GitHub](https://github.com/ivanovslavy/gembapay)

## Support

- Email: contacts@gembapay.com
- GitHub Issues: [github.com/ivanovslavy/gembapay/issues](https://github.com/ivanovslavy/gembapay/issues)

## License

[MIT](LICENSE) © GEMBA EOOD
