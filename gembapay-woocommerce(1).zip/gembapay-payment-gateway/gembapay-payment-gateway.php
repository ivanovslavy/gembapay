<?php
/**
 * Plugin Name: GembaPay Payment Gateway
 * Plugin URI: https://gembapay.com
 * Description: Accept crypto (ETH, BNB, POL, USDC, USDT), credit cards (Stripe), and PayPal payments through a unified checkout. Non-custodial crypto — funds go directly to your wallet.
 * Version: 1.0.0
 * Author: GEMBA EOOD
 * Author URI: https://gembapay.com
 * License: MIT
 * License URI: https://opensource.org/licenses/MIT
 * Text Domain: gembapay
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 9.5
 *
 * @package GembaPay
 */

defined('ABSPATH') || exit;

define('GEMBAPAY_VERSION', '1.0.0');
define('GEMBAPAY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('GEMBAPAY_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Check WooCommerce dependency
 */
function gembapay_check_woocommerce() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="error"><p><strong>GembaPay</strong> requires WooCommerce to be installed and active.</p></div>';
        });
        return false;
    }
    return true;
}

/**
 * Initialize gateway
 */
function gembapay_init() {
    if (!gembapay_check_woocommerce()) {
        return;
    }

    require_once GEMBAPAY_PLUGIN_DIR . 'includes/class-gembapay-gateway.php';
    require_once GEMBAPAY_PLUGIN_DIR . 'includes/class-gembapay-webhook.php';

    add_filter('woocommerce_payment_gateways', function ($gateways) {
        $gateways[] = 'WC_GembaPay_Gateway';
        return $gateways;
    });
}
add_action('plugins_loaded', 'gembapay_init');

/**
 * Register webhook endpoint
 */
function gembapay_register_webhook() {
    add_rewrite_rule(
        'wc-api/gembapay-webhook/?$',
        'index.php?wc-api=gembapay-webhook',
        'top'
    );
}
add_action('init', 'gembapay_register_webhook');

/**
 * Handle webhook
 */
function gembapay_handle_webhook() {
    if (!class_exists('GembaPay_Webhook')) {
        require_once GEMBAPAY_PLUGIN_DIR . 'includes/class-gembapay-webhook.php';
    }
    $webhook = new GembaPay_Webhook();
    $webhook->handle();
}
add_action('woocommerce_api_gembapay-webhook', 'gembapay_handle_webhook');

/**
 * Plugin activation
 */
register_activation_hook(__FILE__, function () {
    flush_rewrite_rules();
});

/**
 * Plugin deactivation
 */
register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});

/**
 * Settings link on plugins page
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=gembapay');
    $links[] = '<a href="' . esc_url($settings_url) . '">Settings</a>';
    $links[] = '<a href="https://docs.gembapay.com" target="_blank">Docs</a>';
    return $links;
});

/**
 * Declare HPOS compatibility
 */
add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});
