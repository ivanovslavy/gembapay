<?php
/**
 * GembaPay WooCommerce Payment Gateway
 *
 * @package GembaPay
 */

defined('ABSPATH') || exit;

class WC_GembaPay_Gateway extends WC_Payment_Gateway {

    private string $api_key;
    private string $webhook_secret;
    private string $api_url;

    public function __construct() {
        $this->id                 = 'gembapay';
        $this->icon               = GEMBAPAY_PLUGIN_URL . 'assets/images/gembapay-badge.svg';
        $this->has_fields         = false;
        $this->method_title       = 'GembaPay';
        $this->method_description = 'Accept crypto (ETH, BNB, POL, USDC, USDT), credit cards, Apple Pay, Google Pay, and PayPal through a unified checkout. Non-custodial crypto payments.';

        $this->supports = ['products', 'refunds'];

        $this->init_form_fields();
        $this->init_settings();

        $this->title          = $this->get_option('title', 'Pay with Crypto, Card or PayPal');
        $this->description    = $this->get_option('description', 'Pay securely with cryptocurrency, credit card, or PayPal.');
        $this->enabled        = $this->get_option('enabled', 'no');
        $this->api_key        = $this->get_option('api_key', '');
        $this->webhook_secret = $this->get_option('webhook_secret', '');
        $this->api_url        = 'https://api.gembapay.com';

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    /**
     * Admin settings fields
     */
    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title'   => 'Enable/Disable',
                'type'    => 'checkbox',
                'label'   => 'Enable GembaPay Payment Gateway',
                'default' => 'no',
            ],
            'title' => [
                'title'       => 'Title',
                'type'        => 'text',
                'description' => 'Payment method title shown at checkout.',
                'default'     => 'Pay with Crypto, Card or PayPal',
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => 'Description',
                'type'        => 'textarea',
                'description' => 'Payment method description shown at checkout.',
                'default'     => 'Pay securely with cryptocurrency (ETH, BNB, POL, USDC, USDT), credit card, Apple Pay, Google Pay, or PayPal.',
                'desc_tip'    => true,
            ],
            'api_key' => [
                'title'       => 'API Key',
                'type'        => 'password',
                'description' => 'Enter your GembaPay API key. Use <code>gembapay_test_...</code> for testing, <code>gembapay_live_...</code> for production. Get your key from <a href="https://merchant.gembapay.com" target="_blank">Merchant Dashboard</a>.',
            ],
            'webhook_secret' => [
                'title'       => 'Webhook Secret',
                'type'        => 'password',
                'description' => sprintf(
                    'Enter your webhook secret from Merchant Dashboard. Set your webhook URL to: <code>%s</code>',
                    home_url('/wc-api/gembapay-webhook/')
                ),
            ],
        ];
    }

    /**
     * Process payment
     */
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        if (!$order) {
            wc_add_notice('Order not found.', 'error');
            return ['result' => 'failure'];
        }

        try {
            $response = $this->api_request('POST', '/api/merchant/payment-request', [
                'orderId'     => (string) $order_id,
                'amount'      => (float) $order->get_total(),
                'currency'    => $order->get_currency(),
                'description' => sprintf('Order #%s from %s', $order_id, get_bloginfo('name')),
            ]);

            if (!empty($response['paymentUrl'])) {
                $order->update_status('pending', 'Awaiting GembaPay payment.');
                $order->update_meta_data('_gembapay_payment_url', $response['paymentUrl']);
                $order->save();

                return [
                    'result'   => 'success',
                    'redirect' => $response['paymentUrl'],
                ];
            }

            throw new \Exception('No payment URL received from GembaPay.');

        } catch (\Exception $e) {
            wc_add_notice('Payment error: ' . $e->getMessage(), 'error');
            $order->add_order_note('GembaPay error: ' . $e->getMessage());
            return ['result' => 'failure'];
        }
    }

    /**
     * Check if gateway is available
     */
    public function is_available() {
        if (empty($this->api_key)) {
            return false;
        }
        return parent::is_available();
    }

    /**
     * API request helper
     */
    private function api_request(string $method, string $endpoint, array $body = []): array {
        $args = [
            'method'  => $method,
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type'  => 'application/json',
                'User-Agent'    => 'gembapay-woocommerce/' . GEMBAPAY_VERSION,
            ],
        ];

        if ($method === 'POST' && !empty($body)) {
            $args['body'] = wp_json_encode($body);
        }

        $response = wp_remote_request($this->api_url . $endpoint, $args);

        if (is_wp_error($response)) {
            throw new \Exception($response->get_error_message());
        }

        $status = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($status >= 400) {
            $msg = $data['message'] ?? $data['error'] ?? "HTTP {$status}";
            throw new \Exception($msg);
        }

        return $data ?? [];
    }

    /**
     * Get webhook secret (used by webhook handler)
     */
    public function get_webhook_secret(): string {
        return $this->webhook_secret;
    }
}
