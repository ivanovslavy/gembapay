<?php
/**
 * GembaPay Webhook Handler
 *
 * @package GembaPay
 */

defined('ABSPATH') || exit;

class GembaPay_Webhook {

    /**
     * Handle incoming webhook
     */
    public function handle() {
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_GEMBAPAY_SIGNATURE'] ?? '';

        // Get gateway settings
        $gateway = $this->get_gateway();
        if (!$gateway) {
            wp_send_json_error(['error' => 'Gateway not configured'], 500);
            return;
        }

        $secret = $gateway->get_webhook_secret();

        // Verify signature
        if (!empty($secret)) {
            $expected = 'sha256=' . hash_hmac('sha256', $payload, $secret);
            if (!hash_equals($expected, $signature)) {
                wp_send_json_error(['error' => 'Invalid signature'], 401);
                return;
            }
        }

        $data = json_decode($payload, true);
        if (!$data || !isset($data['event'])) {
            wp_send_json_error(['error' => 'Invalid payload'], 400);
            return;
        }

        $event = $data['event'];
        $payment = $data['payment'] ?? [];
        $testMode = $data['testMode'] ?? false;
        $orderId = $payment['orderId'] ?? null;

        if (!$orderId) {
            wp_send_json_error(['error' => 'Missing orderId'], 400);
            return;
        }

        $order = wc_get_order($orderId);
        if (!$order) {
            wp_send_json_error(['error' => 'Order not found'], 404);
            return;
        }

        switch ($event) {
            case 'payment.completed':
                $this->handle_completed($order, $payment, $testMode);
                break;

            case 'payment.failed':
                $this->handle_failed($order, $payment);
                break;

            default:
                $order->add_order_note(sprintf('GembaPay webhook: %s', $event));
        }

        wp_send_json_success(['received' => true]);
    }

    /**
     * Handle completed payment
     */
    private function handle_completed(\WC_Order $order, array $payment, bool $testMode) {
        if ($order->is_paid()) {
            return;
        }

        $network = $payment['network'] ?? 'unknown';
        $amount = $payment['usdAmount'] ?? 0;
        $txHash = $payment['txHash'] ?? '';
        $provider = $payment['paymentProvider'] ?? $network;

        $note = sprintf(
            'GembaPay payment completed. Method: %s | Amount: $%s USD | Network: %s',
            $provider,
            number_format($amount, 2),
            $network
        );

        if ($txHash) {
            $note .= sprintf(' | TX: %s', $txHash);
        }

        if ($testMode) {
            $note .= ' | ⚠️ TEST MODE';
        }

        $order->add_order_note($note);
        $order->payment_complete($txHash ?: $order->get_id());

        // Store payment metadata
        $order->update_meta_data('_gembapay_network', $network);
        $order->update_meta_data('_gembapay_provider', $provider);
        $order->update_meta_data('_gembapay_usd_amount', $amount);
        if ($txHash) {
            $order->update_meta_data('_gembapay_tx_hash', $txHash);
        }
        if ($testMode) {
            $order->update_meta_data('_gembapay_test_mode', 'yes');
        }
        $order->save();
    }

    /**
     * Handle failed payment
     */
    private function handle_failed(\WC_Order $order, array $payment) {
        $reason = $payment['reason'] ?? 'Unknown';
        $order->update_status('failed', sprintf('GembaPay payment failed: %s', $reason));
    }

    /**
     * Get gateway instance
     */
    private function get_gateway(): ?WC_GembaPay_Gateway {
        $gateways = WC()->payment_gateways()->payment_gateways();
        return $gateways['gembapay'] ?? null;
    }
}
