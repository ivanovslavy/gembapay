=== GembaPay Payment Gateway ===
Contributors: gembapay
Tags: payments, payment gateway, crypto, cryptocurrency, ethereum, bnb, polygon, usdc, usdt, stripe, paypal, woocommerce, non-custodial, bitcoin, blockchain, web3, checkout, ecommerce, accept crypto, accept payments, fiat payments, apple pay, google pay, defi, smart contract, multi-chain, gateway
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: MIT
License URI: https://opensource.org/licenses/MIT
WC requires at least: 5.0
WC tested up to: 9.5

Accept crypto (ETH, BNB, POL, USDC, USDT), credit cards, Apple Pay, Google Pay, and PayPal through a unified checkout. Non-custodial crypto payments.

== Description ==

**GembaPay** adds a unified payment gateway to your WooCommerce store, letting customers pay with cryptocurrency, credit/debit cards, Apple Pay, Google Pay, or PayPal — all from a single checkout page.

**Non-custodial crypto payments** — Funds go directly from your customer's wallet to yours via smart contracts. GembaPay never holds your money.

= Supported Payment Methods =

**Cryptocurrency (Non-Custodial)**
* ETH (Ethereum)
* BNB (BNB Smart Chain)
* POL (Polygon)
* USDC (stablecoin)
* USDT (stablecoin)

**Cards via Stripe**
* Credit & Debit Cards
* Apple Pay
* Google Pay

**PayPal**
* PayPal Balance
* Bank Account
* Pay Later

= Key Features =

* **Unified checkout** — One payment page for all methods
* **86+ currencies** — Price products in any fiat currency
* **Non-custodial** — Crypto goes directly to your wallet
* **Multi-chain** — Ethereum, BNB Smart Chain, Polygon
* **Automatic order updates** — Webhooks update order status in real-time
* **Test mode** — Full testnet + sandbox support for development
* **HPOS compatible** — Works with WooCommerce High-Performance Order Storage

= Fee Structure =

* Crypto: 1% platform fee (collected on-chain)
* Stripe: 1% + €0.20 + Stripe's standard fees
* PayPal: 1% + €0.20 + PayPal's standard fees

== Installation ==

1. Download the plugin ZIP from the [Merchant Dashboard](https://merchant.gembapay.com) or this repository
2. Go to WordPress Admin → Plugins → Add New → Upload Plugin
3. Upload the ZIP file and click "Install Now"
4. Activate the plugin
5. Go to WooCommerce → Settings → Payments → GembaPay
6. Enter your API Key and Webhook Secret
7. Enable the gateway

= Get Your API Key =

1. Register at [merchant.gembapay.com](https://merchant.gembapay.com)
2. Complete your profile and KYC verification
3. Generate API keys from Settings → API Keys

= Set Your Webhook URL =

In your Merchant Dashboard, set the webhook URL to:

`https://yoursite.com/wc-api/gembapay-webhook/`

= Test Mode =

Use your test API key (`gembapay_test_...`) for development:
* Crypto payments use testnets (Sepolia, BSC Testnet, Polygon Amoy)
* Stripe uses test cards (4242 4242 4242 4242)
* PayPal uses sandbox environment

Switch to your live API key (`gembapay_live_...`) when ready for production.

== Frequently Asked Questions ==

= Do I need a GembaPay account? =

Yes. Register at [merchant.gembapay.com](https://merchant.gembapay.com), complete KYC verification, and generate your API keys.

= Is this non-custodial? =

Yes. Crypto payments go directly from the customer's wallet to your wallet via smart contracts. GembaPay never holds or controls your funds.

= What currencies can I accept? =

You can price products in 86+ fiat currencies. Crypto payments support ETH, BNB, POL, USDC, and USDT. Card and PayPal payments support 51 currencies.

= Can I test before going live? =

Absolutely. Use your test API key to process payments on testnets and sandbox environments with zero risk.

== Changelog ==

= 1.0.0 =
* Initial release
* Unified checkout: crypto, Stripe, PayPal
* Non-custodial crypto via smart contracts
* Multi-chain: Ethereum, BSC, Polygon
* Webhook integration with signature verification
* 86+ fiat currency support
* HPOS compatibility
* Test mode support

== Screenshots ==

1. Plugin settings in WooCommerce
2. Checkout page with GembaPay payment option
3. Unified payment page with all payment methods

== Upgrade Notice ==

= 1.0.0 =
Initial release.
